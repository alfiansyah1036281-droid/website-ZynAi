// @lovable.dev/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only), VITE_* env injection, @ path alias, React/TanStack dedupe,
//     error logger plugins, and sandbox detection (port/host/strictPort).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@lovable.dev/vite-tanstack-config";
import netlify from "@netlify/vite-plugin-tanstack-start";

// Saat di-build di lingkungan Netlify (lewat GitHub → Netlify, BUKAN drag & drop manual),
// plugin ini akan mengarahkan Nitro untuk membuat output yang kompatibel dengan Netlify
// Functions, supaya bagian SSR/server route TanStack Start tetap berjalan di Netlify.
// Lihat netlify.toml di root project untuk build command & publish directory-nya.
export default defineConfig({
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
    // nitro/vite builds from this
    server: { entry: "server" },
  },
  vite: {
    plugins: [netlify()],
  },
});
